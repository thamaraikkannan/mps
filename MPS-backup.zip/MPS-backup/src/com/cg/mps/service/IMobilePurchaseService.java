package com.cg.mps.service;

import java.util.List;

import com.cg.mps.bean.MobilesBean;
import com.cg.mps.bean.PurchaseDetailsBean;
import com.cg.mps.exception.MobileException;

public interface IMobilePurchaseService {
	public int addCustomer(PurchaseDetailsBean Pbean) throws MobileException;
	List<MobilesBean> viewAllMobiles() throws MobileException;
	MobilesBean deleteMobiles(int MobileId) throws MobileException;
	public int priceRangeMobiles(MobilesBean Mbean) throws MobileException;

}
