package com.cg.mps.pl;

import java.util.List;
import java.util.Scanner;


import com.cg.mps.bean.MobilesBean;
import com.cg.mps.bean.PurchaseDetailsBean;
import com.cg.mps.exception.MobileException;
import com.cg.mps.service.MobilePurchaseServiceImpl;

public class MPSApp {

	private static Scanner sc;

	public static void main(String[] args) {

		sc = new Scanner(System.in);
		MobilePurchaseServiceImpl service = new MobilePurchaseServiceImpl();
		MobilesBean Mbean = new MobilesBean();
		PurchaseDetailsBean Pbean = new PurchaseDetailsBean();
		while(true)
		{
			System.out.println("1. Insert Customer Details");
			System.out.println("2. View Details of all mobiles in the shop");
			System.out.println("3. Delete Mobile By MobileId");
			System.out.println("4. Search Mobile By PriceRange");
			System.out.println("5. Exit");
			System.out.println("Enter Your Choice");
			int choice = sc.nextInt();
			
			switch(choice)
			{
			case 1 :
				sc.nextLine();
				System.out.println("Enter Customer Name");
				String name = sc.nextLine();
				System.out.println(" Enter Customer Valid Mailid");
				String emailid = sc.nextLine();
				System.out.println(" Enter Customer Phone Number");
				String Phonenumber = sc.nextLine();
				System.out.println(" Enter the MobileId");
				int number  = sc.nextInt();
				Pbean.setCustomerName(name);
				Pbean.setCustomerMailId(emailid);
				Pbean.setCustomerPhoneNo(Phonenumber);
				Pbean.setMobileId(number);
				try
				{
					service.addCustomer(Pbean);
					int id = service.addCustomer(Pbean);
					System.out.println(" Details Added to database"+id);
				}
				catch(MobileException e)
				{
					System.out.println(e);
				}
				break;
			case 2 :
				try
				{
					List<MobilesBean> list = service.viewAllMobiles();
					/*System.out.println("Mobile Id = "+Mbean.getMobileId());
					System.out.println("Mobile Name = "+Mbean.getMobileName());
					System.out.println("Mobile Price = "+Mbean.getMobilePrice());
					System.out.println("Mobile Quantity = "+Mbean.getMobileQuantity());
					//System.out.println("");*/
					for(MobilesBean ref : list)
					{
						System.out.println(ref);
					}
				}
				catch(MobileException e)
				{
					System.out.println("no rows selected");
				}
				break;
			case 3 :
				System.out.println("Enter MobileId");
				int id1 = sc.nextInt();
				try{
				Mbean = service.deleteMobiles(id1);
				System.out.println("Successfully Deleted");
				}
				catch(MobileException e){
					System.out.println("Id not Found");
				}
				break;
			case 4 :
				System.out.println("Enter the Price Range");
				System.out.println("Enter Minimum amount");
				int minimum = sc.nextInt();
				System.out.println("Enter Maximum amount");
				int maximum = sc.nextInt();
				Mbean.setMin(minimum);
				Mbean.setMax(maximum);
				try{
				service.priceRangeMobiles(Mbean);
				System.out.println("Mobile Id = "+Mbean.getMobileId());
				System.out.println("Mobile Name = "+Mbean.getMobileName());
				System.out.println("Mobile Price = "+Mbean.getMobilePrice());
				System.out.println("Mobile Quantity = "+Mbean.getMobileQuantity());
				}
				catch(MobileException e){
					System.out.println("Id not Found");
				}
				break;
				
			case 5 :
				System.exit(0);
				
			}
			}
		
	}

}
